﻿namespace Ecommerce.Services
{
    public interface IService
    {
    }
}
