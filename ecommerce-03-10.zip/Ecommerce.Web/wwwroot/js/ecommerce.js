$(document).on("click", ".open-detailsModal", function () {
    $('#pic1').attr('src', $(this).data('image').replace("~",""));
    $('#title').html($(this).data('description'));
    $('#price').html($(this).data('price'));
    $('#vendor').html('Vendor: '.concat($(this).data('vendor')));
    $('#serialNumber').html('Serial number: '.concat($(this).data('serial')));
    $('#note').html('note: '.concat($(this).data('note')));
});

function addToCart(productId) {
    $.get('/ShoppingCart/AddToCart?productId=' + productId).done(function (data) {
        $('#itemsNumber').html(data);
        $('#itemsCart').html(data + ' items');
    });
}

//var get_data = function () {
//    var result = false;
//    $.get('/ShoppingCart/AddToCart?='+).done(function (awesome_data) {
//        result = awesome_data;
//    });

//    return result;
//}
