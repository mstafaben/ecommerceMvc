$(document).on("click", ".open-detailsModal", function () {
    //var pic = document.getElementById("pic1");
    //pic.src = $(this).data('image');
    $('#pic1').attr('src', $(this).data('image').replace("~",""));
    $('#title').html($(this).data('description'));
    $('#price').html($(this).data('price'));
    $('#vendor').html('Vendor: '.concat($(this).data('vendor')));
    $('#serialNumber').html('Serial number: '.concat($(this).data('serial')));
    $('#note').html('note: '.concat($(this).data('note')));
});

function displayDetails(product) {

}