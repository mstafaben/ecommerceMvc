﻿namespace Ecommerce.Common.Mapping
{
    public interface IMapFrom<TModel>
    {
    }
}
