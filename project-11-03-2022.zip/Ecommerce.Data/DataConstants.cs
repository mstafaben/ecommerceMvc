﻿namespace Ecommerce.Data
{
    public static class DataConstants
    {
        public const int UserNameMinLength = 2;
        public const int UserNameMaxLength = 100;
        public const int UserUsernameMaxLength = 50;

        public const string itemsNumber = "cart_items_number";

    }

}
