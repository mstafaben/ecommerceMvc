### Shop SummerFox
**Simple cross platform, e-commerce system 
ASP.NET Core &amp; SQL Server**
