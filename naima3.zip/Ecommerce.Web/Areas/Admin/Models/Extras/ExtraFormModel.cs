﻿namespace Ecommerce.Web.Areas.Admin.Models.Extras
{
    using System.ComponentModel.DataAnnotations;

    using Data;
    using Ecommerce.Data;
    using Ecommerce.Data.EntityModels;

    public class ExtraFormModel
    {
        [Required]
        [MaxLength(DataConstants.ExtraNameMaxLength)]
        public string Name { get; set; }

        [Required]
        public Transmission Transmission { get; set; }

        [Required]
        [MaxLength(DataConstants.ExtraDescriptionMaxLength)]
        public string Description { get; set; }
    }
}
