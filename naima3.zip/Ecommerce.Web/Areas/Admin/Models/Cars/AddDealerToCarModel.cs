﻿namespace Ecommerce.Web.Areas.Admin.Models.Cars
{
    public class AddDealerToCarModel
    {
        public int CarId { get; set; }

        public int DealerId { get; set; }
    }
}
