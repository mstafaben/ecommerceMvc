﻿namespace Ecommerce.Web.Areas.Admin.Controllers
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;

    [Area("Admin")]
    //[Authorize(Roles = WebConstants.Admin)]
    public class BaseAdminController : Controller
    {

    }
}
