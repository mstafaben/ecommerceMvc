﻿namespace Ecommerce.Web.Models.HomeViewModels
{
    public class SearchFormModel
    {
        public string SearchText { get; set; }
    }
}
