﻿namespace Ecommerce.Services.Admin.Implementations
{
    using System.Linq;
    using System.Threading.Tasks;
    using System.Collections.Generic;

    using Microsoft.EntityFrameworkCore;

    using AutoMapper.QueryableExtensions;

    using Data;
    using Ecommerce.Web.Data;
    using Admin.Models.Users;

    using Ecommerce.Services.Admin.Contracts;

    public class UserService : IUserService
    {
        private readonly EcommerceDbContext db;

        public UserService(EcommerceDbContext db)
        {
            this.db = db;
        }

        public async Task<IEnumerable<AdminUserListingServiceModel>> AllAsync()
            => await this.db
                .Users
                .OrderBy(u => u.Name)
                .ThenBy(u => u.UserName)
                .ProjectTo<AdminUserListingServiceModel>()
                .ToListAsync();
    }
}
