﻿namespace Ecommerce.Data.EntityModels
{
    public enum Engine
    {
        V12 = 0,
        V10 = 1,
        V8 = 2,
        V6 = 3,
        V5 = 4,
        V4 = 5,
    }
}
