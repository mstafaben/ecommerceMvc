﻿namespace Ecommerce.Data.EntityModels
{
    public enum Brandenum //i don't use it
    {
        Audi = 0,
        BMW = 1,
        Mercedes = 2,
        Volkswagen = 3,
        Toyota = 4,
        Lada = 5,
        Ford = 6,
        Subaru = 7,
        ŠKODA = 8,
        Mazda = 9,
        Honda = 10,
        Chevrolet = 11,
        Nissan = 12,
        Ferrari = 13,
        Lamborghini = 14,
        Bogati = 15,
        Bentley = 16,
        Porsche = 17,

    }
}
