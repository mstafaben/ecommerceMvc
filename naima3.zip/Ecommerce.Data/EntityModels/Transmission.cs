﻿namespace Ecommerce.Data.EntityModels
{
    public enum Transmission
    {
        Manual = 0,
        Automatic = 1,
        Semiautomatic = 2,
    }
}
